import java.io.*;
import java.util.Scanner;
public class UserManager
{
    private static final String ACCOUNTS_FILE = "AccountFile.txt";
    public boolean accountExists(String username)
    {
        try (Scanner scanner = new Scanner(new File(ACCOUNTS_FILE)))
        {
            while (scanner.hasNextLine())
            {
                String line = scanner.nextLine();
                String[] parts = line.split(":");
                if (parts[0].trim().equals(username.trim()))
                {
                    return true;
                }
            }
        }
        catch (FileNotFoundException e)
        {
            System.out.println("Accounts file not found.");
        }
        return false;
    }

    public void createAccount(String username, String password)
    {
        if (accountExists(username) == true)
        {
            System.out.println("Account already exists.");
            return;
        }

        try (PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(ACCOUNTS_FILE, true))))
        {
            writer.println(username + ":" + password);
            System.out.println("Account created successfully.");
        }
        catch (IOException e)
        {
            System.out.println("Error writing to accounts file.");
        }
    }

    public boolean validateUser(String username, String clientHashedPassword)
    {
        try (Scanner scanner = new Scanner(new File(ACCOUNTS_FILE)))
        {
            while (scanner.hasNextLine())
            {
                String line = scanner.nextLine();
                String[] parts = line.split(":");
                String storedUsername = parts[0].trim();
                String storedHashedPassword = parts[1].trim();

                if (storedUsername.equals(username))
                {
                    return clientHashedPassword.equals(storedHashedPassword);
                }
            }
        }
        catch (FileNotFoundException e)
        {
            System.out.println("Accounts file not found.");
        }
        return false;
    }
}
