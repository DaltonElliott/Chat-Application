import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.Socket;
import java.security.*;


class ChatClient extends JFrame implements ActionListener
{
    private final JButton connectButton;
    private final JButton loginButton;
    private final JButton exitButton;
    private final JButton createAccountButton;
    private final JPanel buttonPanel;
    private final JButton chatButton;
    private boolean loginSuccessful = false;
    private BufferedReader in;
    private PrintWriter out;
    private String username;
    private Socket socket;
    private static final String serverAddress = "localhost";
    private static final int port = 1234;

    public static void main(String[] args)
    {
            new ChatClient(serverAddress, port);
    }
    public ChatClient(String serverAddress, int port)
    {
        setTitle("Welcome to Dalton's Chat");

        buttonPanel = new JPanel(new GridLayout(3, 2));

        connectButton = new JButton("Connect to Server");
        connectButton.addActionListener(this);
        buttonPanel.add(connectButton);

        loginButton = new JButton("Log In");
        loginButton.addActionListener(this);
        buttonPanel.add(loginButton);

        createAccountButton = new JButton("Create Account");
        createAccountButton.addActionListener(this);
        buttonPanel.add(createAccountButton);

        chatButton = new JButton("Chat");
        chatButton.addActionListener(this);
        buttonPanel.add(chatButton);

        exitButton = new JButton("Exit");
        exitButton.addActionListener(this);
        buttonPanel.add(exitButton);

        add(buttonPanel, BorderLayout.CENTER);


        setSize(300, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

        connectToServer(serverAddress, port);
    }

    public void connectToServer(String serverAddress, int port)
    {
        try
        {
            socket = new Socket(serverAddress, port);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

            Socket socket2 = new Socket(serverAddress, port);
            ServerConnection serverIn = new ServerConnection(socket2);
            new Thread(serverIn).start();

            JOptionPane.showMessageDialog(buttonPanel, "Connected to Server", "Server Connection", JOptionPane.INFORMATION_MESSAGE);
        }
        catch (IOException e)
        {
            JOptionPane.showMessageDialog(buttonPanel, "Unable to Connect to Server", "Server Connection", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }


    public void actionPerformed(ActionEvent event)
    {
        if (event.getSource() == connectButton) {
            connectToServer(serverAddress, port);
        }

        if (event.getSource() == loginButton) {
            handleLogin();
        }

        if (event.getSource() == createAccountButton) {
            handleCreateAccount();
        }

        if (event.getSource() == exitButton) {
            System.exit(0);
        }

        if (event.getSource() == chatButton)
        {
            if (loginSuccessful == true)
            {
                handleChat();
            }
            else
            {
                JOptionPane.showMessageDialog(buttonPanel, "You Must First Log In", "Chat", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public void handleCreateAccount()
    {
        JFrame createAccountFrame = new JFrame("Create Account");

        JTextArea serverMessage = new JTextArea();
        serverMessage.setEditable(false);
        serverMessage.setLineWrap(true);
        serverMessage.setWrapStyleWord(true);

        JScrollPane scrollPane = new JScrollPane(serverMessage);

        JPanel titlePanel = new JPanel(new BorderLayout());
        JLabel titleLabel = new JLabel("Message from Server", SwingConstants.CENTER);
        titlePanel.add(titleLabel, BorderLayout.NORTH);

        JPanel inputPanel = new JPanel(new GridLayout(5, 2));
        JTextField usernameField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        JButton createButton = new JButton("Create Account");

        inputPanel.add(new JLabel("Username:"));
        inputPanel.add(usernameField);
        inputPanel.add(new JLabel("Password:"));
        inputPanel.add(passwordField);
        inputPanel.add(createButton);

        createAccountFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        createAccountFrame.setLayout(new BorderLayout());
        createAccountFrame.add(titlePanel, BorderLayout.NORTH);
        createAccountFrame.add(scrollPane, BorderLayout.CENTER);
        createAccountFrame.add(inputPanel, BorderLayout.SOUTH);
        createAccountFrame.setSize(500, 300);
        createAccountFrame.setVisible(true);

        createButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                try {
                    out.println("***CREATEACCOUNT***");
                    sendCredentials(username, password);
                } catch (IOException ex) {
                    System.out.println("Unable to Send Credentials");
                }
            }
        });

        Thread readerThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    while (true) {
                        String input = in.readLine();
                        if (input == null) {
                            break;
                        }

                        if(input.equals("Account Created"))
                        {
                            JOptionPane.showMessageDialog(buttonPanel,"Account Created","Account Status",JOptionPane.INFORMATION_MESSAGE);
                            createAccountFrame.dispose();
                        }

                        SwingUtilities.invokeLater(new Runnable() {
                            @Override
                            public void run() {
                                serverMessage.append(input + "\n");
                            }
                        });
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        readerThread.start();
    }

    public void handleLogin()
    {
        JFrame loginFrame = new JFrame("Login");

        JTextArea serverMessage = new JTextArea();
        serverMessage.setEditable(false);
        serverMessage.setLineWrap(true);
        serverMessage.setWrapStyleWord(true);

        JScrollPane scrollPane = new JScrollPane(serverMessage);

        JPanel titlePanel = new JPanel(new BorderLayout());
        JLabel titleLabel = new JLabel("Message from Server", SwingConstants.CENTER);
        titlePanel.add(titleLabel, BorderLayout.NORTH);

        JPanel inputPanel = new JPanel(new GridLayout(5, 2));
        JTextField usernameField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        JButton createButton = new JButton("Log In");

        inputPanel.add(new JLabel("Username:"));
        inputPanel.add(usernameField);
        inputPanel.add(new JLabel("Password:"));
        inputPanel.add(passwordField);
        inputPanel.add(createButton);

        loginFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        loginFrame.setLayout(new BorderLayout());
        loginFrame.add(titlePanel, BorderLayout.NORTH);
        loginFrame.add(scrollPane, BorderLayout.CENTER);
        loginFrame.add(inputPanel, BorderLayout.SOUTH);
        loginFrame.setSize(500, 300);
        loginFrame.setVisible(true);

        createButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                try {
                    out.println("***LOGIN***");
                    sendCredentials(username, password);
                } catch (IOException ex) {
                    System.out.println("Unable to Send Credentials");
                }
            }
        });

        Thread readerThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    while (true)
                    {
                        String input = in.readLine();

                        if (input == null)
                        {
                            break;
                        }

                        if(input.equals("Login Successful"))
                        {
                            loginSuccessful = true;
                            JOptionPane.showMessageDialog(buttonPanel,"Login Successful","Login Successful",JOptionPane.INFORMATION_MESSAGE);
                            loginFrame.dispose();
                        }

                        SwingUtilities.invokeLater(new Runnable() {
                            @Override
                            public void run() {
                                serverMessage.append(input + "\n");
                            }
                        });
                    }
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
            }
        });
        readerThread.start();
    }


    public void handleChat()
    {
        JFrame chatFrame = new JFrame("Chat");

        JButton sendButton = new JButton("Send");
        JButton clearButton = new JButton("Clear");

        JTextArea serverMessage = new JTextArea();
        serverMessage.setEditable(false);
        serverMessage.setLineWrap(true);
        serverMessage.setWrapStyleWord(true);

        JScrollPane scrollPane = new JScrollPane(serverMessage);

        JPanel titlePanel = new JPanel(new BorderLayout());
        JLabel titleLabel = new JLabel(username + "'s Chat", SwingConstants.CENTER);
        titlePanel.add(titleLabel, BorderLayout.NORTH);

        JPanel inputPanel = new JPanel(new GridLayout(5, 3));
        JTextField messageField = new JTextField();

        inputPanel.add(new JLabel("Enter Message. Limit Input to 256 Characters, excluding spaces. ", SwingConstants.CENTER));
        inputPanel.add(messageField);
        inputPanel.add(sendButton);
        inputPanel.add(clearButton);

        chatFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        chatFrame.setLayout(new BorderLayout());
        chatFrame.add(titlePanel, BorderLayout.NORTH);
        chatFrame.add(scrollPane, BorderLayout.CENTER);
        chatFrame.add(inputPanel, BorderLayout.SOUTH);
        chatFrame.setSize(500, 300);
        chatFrame.setVisible(true);

        messageField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                String message = messageField.getText();
                if (e.getKeyCode() == KeyEvent.VK_ENTER)
                {
                    if (message.isEmpty())
                    {
                        JOptionPane.showMessageDialog(chatFrame, "Nothing to Send");
                    }
                    else if (message.replaceAll("\\s+", "").length() > 256)
                    {
                        JOptionPane.showMessageDialog(chatFrame, "Message should be less than 256 characters (excluding spaces).");
                    }
                    else
                    {
                        out.println("***CHAT***");
                        sendMessage(message);
                        clear(messageField);
                    }

                    messageField.setEnabled(false);
                    Timer cooldownTimer = new Timer(1000, new ActionListener()
                    {
                        @Override
                        public void actionPerformed(ActionEvent e)
                        {
                            messageField.setEnabled(true);
                        }
                    });
                    cooldownTimer.setRepeats(false);
                    cooldownTimer.start();
                }
            }
        });

        sendButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                String message = messageField.getText();

                if (message.isEmpty())
                {
                    JOptionPane.showMessageDialog(chatFrame, "Nothing to Send");
                }
                else if (message.replaceAll("\\s+", "").length() > 256)
                {
                    JOptionPane.showMessageDialog(chatFrame, "Message should be less than 256 characters (excluding spaces).");
                }
                else
                {
                    out.println("***CHAT***");
                    sendMessage(message);
                    clear(messageField);
                }

                sendButton.setEnabled(false);
                Timer cooldownTimer = new Timer(1000, new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        sendButton.setEnabled(true);
                    }
                });
                cooldownTimer.setRepeats(false);
                cooldownTimer.start();
            }
        });

        clearButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e) {
                clear(messageField);
            }
        });
    }

    public void sendCredentials(String username, String password) throws IOException
    {
        out.println(username);
        out.println(hashPassword(password));
    }

    public void sendMessage(String message)
    {
      out.println(message);
    }

    public void clear( JTextField messageField)
    {
        messageField.setText("");
    }

    private String hashPassword(String password)
    {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();

            for (byte b : hash)
            {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }

            return hexString.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
