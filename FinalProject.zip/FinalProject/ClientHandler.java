import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
public class ClientHandler extends Thread
{
    private UserManager userManager = new UserManager();
    private Socket link;
    private PrintWriter output;
    private ArrayList<ClientHandler> threads;

    public ClientHandler(Socket link, ArrayList<ClientHandler> threads)
    {
        this.link = link;
        this.threads = threads;
    }

    @Override
    public void run()
    {
        String username = null;
        try
        {
            BufferedReader in = new BufferedReader(new InputStreamReader(link.getInputStream()));
            output = new PrintWriter(link.getOutputStream(), true);
            String line;

            while ((line = in.readLine()) != null)
            {
                if(line.equals("***CREATEACCOUNT***"))
                {
                    username = in.readLine();
                    String password = in.readLine();

                    if (userManager.accountExists(username))
                    {
                        output.println("Account Already Exists!");
                    }
                    else
                    {
                        output.println("Account Created");
                        userManager.createAccount(username, password);
                    }
                }
                else if (line.equals("***LOGIN***"))
                {
                    username = in.readLine();
                    String password = in.readLine();

                    if (userManager.validateUser(username, password))
                    {
                        output.println("Login Successful");
                    }
                    else
                    {
                        output.println("Login Unsuccessful");
                    }
                }
                else if (line.equals("***CHAT***"))
                {
                    String message = in.readLine();
                    broadcastMessage(username, message);
                    System.out.println(username + ": " + message);
                }
            }
        }
        catch (IOException e)
        {
            System.out.println("Client disconnected: " + username);
            threads.remove(this);
            try
            {
                link.close();
            }
            catch (IOException ioEx)
            {
                System.out.println("Error closing socket");
            }
        }
    }

    public void broadcastMessage(String username, String message)
    {
        synchronized (threads)
        {
            for (ClientHandler client: threads)
            {
                try {
                    client.output.println(username + ": " + message);
                    client.output.flush();
                } catch (Exception e) {
                    System.out.println("Failed to send message to client: " + ". Error: " + e.getMessage());
                }
            }
        }
    }
}
